Done in Python3.

